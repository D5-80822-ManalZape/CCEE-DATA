package mypack1;

public class First
{
	public int a;
	private int b;
	int c;		//default
	protected int d;
	
	void firstFun()
	{
		System.out.println(a);	//OK
		System.out.println(b);	//OK
		System.out.println(c);	//OK
		System.out.println(d);	//OK
	}
}


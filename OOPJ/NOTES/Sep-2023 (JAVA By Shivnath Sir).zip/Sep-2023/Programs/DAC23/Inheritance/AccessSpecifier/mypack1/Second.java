package mypack1;

public class Second extends First
{
	void secondFun()
	{
		System.out.println(a);	//OK
		System.out.println(b);	//ERROR
		System.out.println(c);	//OK
		System.out.println(d);	//OK
	}		
}

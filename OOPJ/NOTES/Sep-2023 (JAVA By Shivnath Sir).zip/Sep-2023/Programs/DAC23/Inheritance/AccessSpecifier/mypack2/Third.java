package mypack2;
import mypack1.First;

public class Third extends First
{
	void thirdFun()
	{
		System.out.println(a);	//OK
		System.out.println(b);	//ERROR
		System.out.println(c);	//ERROR
		System.out.println(d);	//OK
	}
}

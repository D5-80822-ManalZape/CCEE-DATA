abstract class First
{
	abstract void myFun();
	
	void anotherFun()
	{
		System.out.println("anotherFun of First");
	}
}

class Second extends First
{
	void myFun()
	{
		System.out.println("myFun of Second");
	}
}

class AbstractDemo
{
	public static void main(String args[])
	{
		//new First();
		Second s = new Second();
		s.myFun();
		s.anotherFun();
	}
}

class Second
{
	String name;
	
	Second()
	{
	}
	
	Second(String name)
	{
		this.name = name;
	}
	
	void myFun()
	{
		Second s = new Second("obj3");		//obj3
		//code
	}
	
	public void finalize()
	{
		//pretask before freeing up the object
		System.out.println("finalize() called for "+ this.name);
	}
}

class GarbageCollectionDemo
{
	public static void main(String args[])
	{		
		Second s1 = new Second("obj1"); 	//obj1
		Second s2 = new Second("obj2");		//obj2
		
		s1.myFun();

		s2 = null;		//Nullyfying the reference variable
		s1 = new Second("obj4");//Reassigning the reference variable
		new Second("obj5");			//Anonymous object as its reference not stored
		
		String s1 = "Hello";
		s1 = null;

		//System.gc();
		Runtime.getRuntime().gc();
		System.out.println("Program execution completed!!");
	}
}


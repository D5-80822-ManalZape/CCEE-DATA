class First
{
	void myFun()
	{
		System.out.println("myFun of First");
	}
}

class Second extends First
{
	void anotherFun()
	{
		System.out.println("anotherFun of Second");
	}
}

class Third
{
}

class CastingDemo
{
	public static void main(String args[])
	{
		First f ;  
		Second s = new Second();
		Third t = new Third();

		f = s;				//Parent = Child
		s = (Second)f;				//Child = Parent

		s.myFun();
		s.anotherFun();

		//f = (First)t;			//ERROR; as there is no inheritance between First & Third

		

		System.out.println("Program working successfully");
	}
}


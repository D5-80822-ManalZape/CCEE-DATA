class First
{
	void myFun()
	{
		System.out.println("myFun of First");
	}
}

class Second extends First
{
	void anotherFun()
	{
		System.out.println("anotherFun of Second");
	}
}

class Third
{
}

class CastingDemo1
{
	public static void main(String args[])
	{
		First f ;  
		Second s = new Second();

		f = s;

		((Second)f).anotherFun();	

		f = new First();
		f = new Second();
		s = (Second)f; 		//Runtime Error

		//s.anotherFun();

		System.out.println("Program working successfully");
	}
}


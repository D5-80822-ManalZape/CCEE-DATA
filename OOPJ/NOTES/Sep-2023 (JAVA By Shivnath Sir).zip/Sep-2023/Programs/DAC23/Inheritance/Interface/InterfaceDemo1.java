interface MyInterface1
{
	void fun1();
}

interface MyInterface2 
{
	void fun2();
}

interface MyInterface3 extends MyInterface1, MyInterface2
{
	void fun3();
}

class Demo implements MyInterface3
{
	//We will have to implement both fun1() and fun2() here.
	public void fun1()
	{
		//code
	}
	public void fun2()
	{
		//code
	}
	public void fun3()
	{
		//code
	}
}

class InterfaceDemo1
{
	public static void main(String args[])
	{	
	}
}

class First
{
	private int a;
	
	First()
	{
		System.out.println("zero-arg constructor of First");
		a = 1;
	}
	
	First(int a)
	{
		System.out.println("one-arg constructor of First");
		this.a = a;
	}
	
	void print()
	{
		System.out.println(a);
	}
}

class Second extends First
{
	int b;
	
	Second()
	{
		System.out.println("zero-arg constructor of Second");
		b = 1;
	}
	
	Second(int a, int b)
	{
		super(a);
		System.out.println("two-arg constructor of Second");
		this.b = b;
	}
	
	void print()
	{
		super.print();
		System.out.println(b);
	}
	
}


class SuperConstructorDemo
{
	public static void main(String args[])
	{
		Second s = new Second(5,10);
		s.print();
	}
}


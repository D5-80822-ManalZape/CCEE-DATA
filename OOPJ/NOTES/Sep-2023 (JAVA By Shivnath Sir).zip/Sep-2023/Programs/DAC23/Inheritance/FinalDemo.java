class Global
{
	final static String year = "2023"; 
}

class First
{
	final int val = 5;	//Intialize at one place only -> either here or inside constructor

	First()
	{
		//val = 5;
	}

	final void print()		//Overridden method
	{
		System.out.println(val);
		//Global.year = "2024";		//ERROR
	}
}

class Second extends First
{
	int num = 10;

	void printDetails()			//Overriding method
	{
		super.print();
		System.out.println(num);		
	}
}

class FinalDemo
{
	public static void main(String args[])
	{
		//final local variable.
		final int a;
		a = 10;
		//a = 15;		//ERROR
		System.out.println(a);

		First f = new First();
		f.print();

		Second s = new Second();
		s.printDetails();
	}
}

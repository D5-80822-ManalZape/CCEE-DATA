class First
{
	int a;
	int b;

	First()
	{
	}

	First(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
}

class ObjectClassMethodsDemo
{
	public static void main(String args[])
	{
		First f1 = new First(5,10);
		First f2 = new First(5,10);
		
		//boolean equals()
		if(f1.equals(f2))
		{
			System.out.println("f1 & f2 are equal");
		}
		else
		{	
			System.out.println("f1 & f2 are not equal");
		}

		//int hashCode()
		System.out.println("hashcode of f1: " + f1.hashCode());
		System.out.println("hashcode of f2: " + f2.hashCode());
		
		//String toString()
		System.out.println("f1.toString(): "+f1.toString());		
		System.out.println("f2.toString(): "+f2.toString());		
		System.out.println(f2);		//Internally it will call f2.toString();		

		if(f1 == f2)		//shallow comparison
		{
			System.out.println("f1 == f2");
		}
		else
		{
			System.out.println("f1 != f2");
		}
	}
}

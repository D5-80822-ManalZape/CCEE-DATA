class First
{
	private void myFun()
	{
		System.out.println("myFun of First");
	}
}

class Second extends First
{
	public void myFun()
	{
		super.myFun();
		System.out.println("myFun of Second");
	}	
}

class ChangeSpecifierDemo
{
	public static void main(String args[])
	{
		First s = new Second();
		((Second)s).myFun();
	}
}

class First
{
	void myFun()
	{
		System.out.println("myFun() of First");
	}
	
	void myFun(int a)	//overloaded method
	{
		System.out.println("myFun(int) of First");
	}
}

class Second extends First
{
	void myFun()			//Overriding method
	{
		System.out.println("myFun() of Second");
	}
	
	void anotherFun()
	{
		System.out.println("anotherFun() of Second");
	}
}

class BindingDemo
{
	public static void main(String args[])
	{
		First f = new First();
		f.myFun();	//static binding
		
		Second s = new Second();
		s.myFun();	//dynamic binding
		
		f = new Second();
		f.myFun();	//dynamic binding
	}
}


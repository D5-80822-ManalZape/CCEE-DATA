import java.util.Scanner;
class ScannerDemo
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);

		String str;
		System.out.println("Enter any string");
		str = sc.next();
		sc.nextLine();

		String line;
		System.out.println("Enter any sentence");
		line = sc.nextLine();


		int ival;
		System.out.println("Enter any integer value");
		ival = sc.nextInt();

		double dval;
		System.out.println("Enter any double value");
		dval = sc.nextDouble();

		boolean boolval;
		System.out.println("Enter any boolean value(true/false)");
		boolval = sc.nextBoolean();

		System.out.println("Entered values are:");
		System.out.println("str: "+str);
		System.out.println("line: "+line);
		System.out.println("ival: "+ival);
		System.out.println("dval: "+dval);
		System.out.println("boolval: "+boolval);
		
	}
}

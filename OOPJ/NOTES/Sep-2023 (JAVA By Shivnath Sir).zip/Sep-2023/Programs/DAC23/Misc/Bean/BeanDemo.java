class Demo implements Serializable
{
	private int a;
	private int b;

	Demo()
	{
	}

	Demo(int a, int b)
	{
		this.a = a;
		this.b = b;
	}

	int getA()
	{
		return a;
	}

	int getB()
	{
		return b;
	}

	void setA(int a)
	{
		if(a > 0)
			this.a = a;
	}

	void setB(int b)
	{
		this.b = b;
	}

	public String toString()
	{
		return "Demo[a = " + a + ", b = " + b + "]";
	}

}

class BeanDemo
{
	public static void main(String args[])
	{
		Demo d1 = new Demo(5,10);
		int val = d1.getA();
		System.out.println(val);
		//d1.a = 20;		//error, as a is private
		d1.setA(20);
		System.out.println(d1);
	}
}

import java.util.*;

public class NotBackedSetDemo {

    public static void main(String[] args) {
        List<String> listNames = new ArrayList<String> ();
        listNames.add("Ram");
        listNames.add("Geeta");
        listNames.add("Mohan");

	//List to array
        Object[] names = listNames.toArray();
        listNames.set(0, "Ramesh");
	System.out.println("List contents:" + listNames.toString());
        System.out.println("Array contents: " + Arrays.toString(names));
    }
}


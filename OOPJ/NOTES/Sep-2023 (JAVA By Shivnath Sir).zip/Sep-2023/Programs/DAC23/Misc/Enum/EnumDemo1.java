enum TshirtColor
{
	//RED,GREEN,ORANGE,WHITE,BLACK;		//Named constant, only these are the objects of this enum TshirtColor
	RED(4),GREEN(5),ORANGE(3),WHITE(2),BLACK(4);	//Only these are the objects of this enum TshirtColor
	int rating;

	TshirtColor()		//Can have constructor
	{
		System.out.println("Constructor called");
	}

	TshirtColor(int rating)
	{
		System.out.println("one arg constrctor called");
		this.rating = rating;
	}

	void setRating(int rating)
	{
		this.rating = rating;
	}
}

class EnumDemo1
{
	public static void main(String args[])
	{
		//TshirtColor tcolor1 = new TshirtColor();		//ERROR, Can't be intstantiated 
		TshirtColor tcolor1 = TshirtColor.WHITE;
		System.out.println("Rating of the WHITE tshirt is : " + tcolor1.rating);

		tcolor1.setRating(5);
		System.out.println("Rating of the WHITE tshirt is now : " + TshirtColor.WHITE.rating);

		TshirtColor.RED.setRating(3);
		System.out.println("Rating of the RED tshirt is now : " + TshirtColor.RED.rating);

		//switch(tcolor1)
		switch(TshirtColor.WHITE)
		{
			case RED:
				System.out.println("Tshirt coloer is red");
				break;

			case GREEN:
				System.out.println("Tshirt coloer is green");
				break;

			case ORANGE:
				System.out.println("Tshirt coloer is orange");
				break;

			case WHITE:
				System.out.println("Tshirt coloer is white");
				break;

			case BLACK:
				System.out.println("Tshirt coloer is black");
				break;
			default:
				System.out.println("No color");

		}

		System.out.println("Ordinal value of WHITE : " + TshirtColor.WHITE.ordinal());
		TshirtColor tcolor2 = TshirtColor.BLACK;

		if(tcolor1.equals(tcolor2))
		{
			System.out.println("tcolor1 and tcolor2 are equal");
		}
		else
		{
			System.out.println("tcolor1 and tcolor2 are not equal");
		}

	}
}

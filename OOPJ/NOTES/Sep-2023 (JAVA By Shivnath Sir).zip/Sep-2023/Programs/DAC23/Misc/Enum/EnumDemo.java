enum Role
{
	ADMIN,FACULTY,STUDENT;
}

class User 
{
	String userId;
	Role role;
}

class EnumDemo
{
	public static void main(String args[])
	{
		Role role1 = Role.ADMIN;
		System.out.println(role1);

		Role role2 = Role.STUDENT;
		System.out.println(role2);

		User user = new User();
		user.userId = "U235";
		user.role = Role.STUDENT;

		System.out.println(user.userId + "," + user.role);

	}
}

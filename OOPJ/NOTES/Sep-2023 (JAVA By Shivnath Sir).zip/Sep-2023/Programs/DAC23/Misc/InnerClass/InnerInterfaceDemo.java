interface MyInterface
{
	void myFun();

	interface MyInnerInterface
	{
		void myInnerFun();
	}
}

class MyClass implements MyInterface.MyInnerInterface	//It will implement only inner interface methods.
{
	public void myInnerFun()
	{
		System.out.println("myInnerFun of MyClass");
	}
}

class First implements MyInterface	//It will implement only outer interface methods
{
	public void myFun()
	{
		System.out.println("myFun of First");
	}
}

class InnerInterfaceDemo
{
	public static void main(String args[])
	{
		MyClass mcls = new MyClass();
		mcls.myInnerFun();

		First f = new First();
		f.myFun();
	}
}

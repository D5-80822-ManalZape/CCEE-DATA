interface MyInterface
{
	void oneFun();

	class MyClass
	{
		void myFun()
		{
			System.out.println("myFun of MyInterface.MyInnerclass");
		}
	}
}

class InterfaceInnerClassDemo
{
	public static void main(String args[])
	{
		MyInterface.MyClass mcls = new MyInterface.MyClass();
		mcls.myFun();
	}
}

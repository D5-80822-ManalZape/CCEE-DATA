import java.util.function.*;
import java.util.*;

class ConsumerForEachForListDemo
{
	public static void main(String args[])
	{
		List<String> myList = new ArrayList<String>();
		myList.add("Mohit");
		myList.add("Geeta");
		myList.add("Aakash");

		//If List<Student> then in the following code String will be replaced by Student
		Consumer<String> cs = new Consumer<String>(){
			public void accept(String s)
			{
				System.out.println(s);
			}
		};

		myList.forEach(cs);
		System.out.println("-----------------");

		//Lambda exp for Consumer implementation.
		Consumer<String> cos = s -> System.out.println(s);
		myList.forEach(cos);

		System.out.println("-----------------");

		//Passing functionality using lambda as argument
		myList.forEach(s -> System.out.println(s));
	}
}

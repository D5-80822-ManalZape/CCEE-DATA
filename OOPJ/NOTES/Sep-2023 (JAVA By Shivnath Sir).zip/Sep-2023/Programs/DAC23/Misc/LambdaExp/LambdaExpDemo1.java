interface MyInterface
{
	void print(int a);

}

interface Hello
{
	void saySomething();
}

class LambdaExpDemo1
{
	public static void main(String args[])
	{
		//1st way
		MyInterface mif1 = (a) -> System.out.println(a);
		mif1.print(10);

		//2nd way: If only one parameter, we can leave the parentheses.
		MyInterface mif2 = a -> System.out.println(a);
		mif2.print(20);

		//Hello implementation using lambda
		Hello hl1 = () -> System.out.println("Hi friends");
		//Hello hl1 = () -> 5;
		hl1.saySomething();
	}

}

import java.io.*;

class ThrowsDemo
{
	static void myFun() throws ArithmeticException,IOException	//called method
	{
		System.out.println("myFun called");
		int res = 5/0;
		
		//Code: Reading a file which does not exist in file path: This will generate IOException
	}
	
	public static void main(String args[])		//main is calling method
	{
		try
		{
			myFun();
		}
		catch(IOException excp)
		{
			System.out.println("IOException caught inside main");
		}
		catch(ArithmeticException ae)
		{
			System.out.println("ArithmeticException caught inside main");
		}
		System.out.println("Program terminated successfully");
	}
}

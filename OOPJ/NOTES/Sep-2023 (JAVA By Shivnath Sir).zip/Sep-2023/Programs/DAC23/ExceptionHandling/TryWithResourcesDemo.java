import java.io.*;

class TryWithResourcesDemo
{
	public static void main(String args[])
	{
		try
		{
			try(FileReader fr = new FileReader("/home/shivnath/myfile.txt"); PrintWriter pr = new PrintWriter("/home/shivnath/output.txt"))
			{
				//fr = new FileReader("/home/shivnath/myanotherfile.txt");
				System.out.println("within try block");
			}
			catch(FileNotFoundException e)
			{
				System.out.println("IOException caught");
			}
			
		}
		catch(IOException excp)
		{
			System.out.println("File not found exception");
		}

		System.out.println("Program execution completed successfully!!");

	}
}

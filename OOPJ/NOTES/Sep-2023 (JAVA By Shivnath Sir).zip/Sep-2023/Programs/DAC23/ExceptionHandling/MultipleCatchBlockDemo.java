class MultipleCatchBlockDemo
{
	public static void main(String args[])
	{
		try
		{
			int res = 5/0;
		}
		catch(Exception e)
		{
		}
		catch(ArithmeticException ae)
		{
		}
		System.out.println("Program execution completed successfully!!");
	}
}



class RethrowDemo
{
	public static void myFun()
	{
		try
		{
			int res = 5/0;
		}
		catch(ArithmeticException ae)
		{
			System.out.println("ArithmeticException caught here inside myFun");
			throw ae;		//Rethrowing the exception
		}
	}
	
	
	public static void main(String args[])
	{
		System.out.println("Program execution started..");
		try
		{
			myFun();
		}
		catch(ArithmeticException ae)
		{
			System.out.println("ArithmeticException caught here inside main");
		}		
		System.out.println("Program execution completed successfully!!");
	}
}

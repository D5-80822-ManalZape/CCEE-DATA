class FinallyDemo
{
	public static void main(String args[])
	{
		System.out.println("Program execution started...");
		int arr[] = {2,4,6,8,10};

		try
		{
			//resource open
			for(int i = 0; i < 5; i++)
			{
				System.out.println(arr[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println("exception caught and handled");
			//resource close
		}
		finally
		{
			//This part will always execute whether exception occurs or not.
			System.out.println("finally block executed");
		}

		System.out.println("Program executed successfully!!");
	}
}

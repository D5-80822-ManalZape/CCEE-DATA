import java.io.*;

class MyException extends Exception		//Checked exception
{
	MyException()
	{
	}
		
	MyException(String msg)
	{
		super(msg);
	}
}

class UserDefinedCheckedExceptionClassDemo1
{
	static void myFun() throws MyException
	{
		System.out.println("myFun called");
		throw new MyException("MyException object");
	}
	
	public static void main(String args[])
	{
		myFun();		
		System.out.println("Program terminated successfully");
	}
}








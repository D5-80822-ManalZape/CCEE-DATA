class ThrowDemo
{
	public static void main(String args[])
	{
		System.out.println("Program execution started...");
		try
		{
			System.out.println("try block");
			//ArithmeticException excp = new ArithmeticException();
			//throw excp;
		
			throw new ArithmeticException("Number division by zero exception");
		}
		catch(Exception ae)
		{
			//System.out.println("ArithmeticException caught : "+ae.getMessage());
			ae.printStackTrace();
		}
		System.out.println("Program execution completed successfully");
	}
	
}

import java.io.*;

class ThrowsIOExceptionDemo
{
	static void myFun() throws IOException
	{
		anotherFun();
	}
	
	static void anotherFun() throws IOException
	{
		//code
		throw new IOException("Explicitly generated IOException");
	}
	
	public static void main(String args[]) throws IOException
	{
		System.out.println("Program started...");
		myFun();
		System.out.println("Program executed successfully!!");
	}
}

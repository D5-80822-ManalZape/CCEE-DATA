package firstpack;

public class First
{
	public void myFun()
	{
		System.out.println("myFun of First");
	}
}

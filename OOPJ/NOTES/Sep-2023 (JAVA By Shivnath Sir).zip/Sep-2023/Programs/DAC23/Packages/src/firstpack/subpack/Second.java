package firstpack.subpack;

public class Second
{
	public void myFun()
	{
		System.out.println("myFun of Second");
	}
}

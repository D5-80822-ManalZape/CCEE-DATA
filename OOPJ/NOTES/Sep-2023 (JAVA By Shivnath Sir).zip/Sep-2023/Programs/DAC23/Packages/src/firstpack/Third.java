package firstpack;

public class Third
{
	public void myFun()
	{
		System.out.println("myFun of Third");
	}
}

class Fourth
{
	
}

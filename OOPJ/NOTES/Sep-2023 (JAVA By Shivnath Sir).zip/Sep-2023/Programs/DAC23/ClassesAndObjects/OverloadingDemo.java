class AddCalculator
{
	void add(int a,int b)
	{
		System.out.println("add(int,int) method called");
		System.out.println(a+b);
	}
	
	/*void add(double a, double b)
	{
		System.out.println("add(double,double) method called");
		System.out.println(a+b);
	}*/
}

class OverloadingDemo
{
	public static void main(String args[])
	{
		AddCalculator addCal = new AddCalculator();
		addCal.add(2.5,3.7);
		//addCal.add(2,3);
		//addCal.add(2,3.7);
	}
}

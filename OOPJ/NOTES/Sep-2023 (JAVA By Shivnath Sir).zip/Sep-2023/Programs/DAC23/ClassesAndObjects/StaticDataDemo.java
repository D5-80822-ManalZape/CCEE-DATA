class Demo
{
	int a;		//non-static
	int b;		//non-static
	static int c;	//static, as it is int its default value is 0.
	
	Demo()
	{
	}
	
	Demo(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
	
	void increment()
	{
		c++;
	}
	
	void print()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}

class StaticDataDemo
{
	public static void main(String args[])
	{
		System.out.println("static c = " + Demo.c);
		Demo.c += 1;	//Demo.c = Demo.c + 1;

		System.out.println("static c = " + Demo.c);

		Demo d1 = new Demo(2,4);
		System.out.println("static c = " + d1.c);

		/*d1.increment();
		d1.print();
		
		Demo d2 = new Demo(6,8);
		d2.increment();
		d2.print();
		
		Demo d3 = new Demo(10,12);
		d3.increment();
		d3.print();*/
		
	}
}


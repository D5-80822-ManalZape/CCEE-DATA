class Demo
{
	int a;
	int b;
	static int c;
	
	static void increment()
	{
		c++;
		//System.out.println(a);		//ERROR
		//System.out.println(c);
		//print();				//ERROR
	}


	static void myFun()
	{
		Demo d = new Demo();
		d.print();		//OK, obj.non-static

		print();		//ERROR
	}	

	void print()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);			//OK
		increment();				//OK
	}
}

class StaticMethodDemo
{
	public static void main(String args[])
	{
		Demo.increment();	//OK, classname.staticmethod

		Demo d1 = new Demo();
		d1.print();
	}
}


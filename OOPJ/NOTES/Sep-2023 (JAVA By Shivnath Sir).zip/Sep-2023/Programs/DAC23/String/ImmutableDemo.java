class ImmutableDemo
{
	public static void main(String args[])
	{
		String s1 = "Hello";
		String s2 = s1.concat(" Friends");
		System.out.println("s1 = " + s1);
		System.out.println("s2 = " + s2);

		String s3 = "Hello Friends";
		System.out.println(s2 == s3 ? "s2 == s3" : "s2 != s3");
	}
}

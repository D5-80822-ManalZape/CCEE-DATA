class StringDemo
{
	public static void main(String args[])
	{
		String str1 = "welcome";
		String str2 = new String("welcome");

		String str3 = "welcome";
		String str4 = new String("welcome");

		System.out.println(str1 == str2 ? "str1 == str2" : "str1 != str2" );
		System.out.println(str1 == str3 ? "str1 == str3" : "str1 != str3" );
		System.out.println(str2 == str3 ? "str2 == str3" : "str2 != str3" );
		System.out.println(str2 == str4 ? "str2 == str4" : "str2 != str4" );

	}
}

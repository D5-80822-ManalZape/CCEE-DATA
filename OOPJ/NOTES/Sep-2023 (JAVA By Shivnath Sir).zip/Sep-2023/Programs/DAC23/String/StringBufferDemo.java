class StringBufferDemo
{
	public static void main(String args[])
	{
		StringBuffer str1 = new StringBuffer("welcome");
		StringBuffer str2 = new StringBuffer("welcome");

		System.out.println(str1.length());
		
		//capacity
		System.out.println(str1);
		System.out.println(str1.capacity());

		//append()
		str1.append(" Friends");

		System.out.println(str1);
		System.out.println(str1.capacity());

		str1.append(" Friends");		//Now capacity is full
		System.out.println(str1);
		System.out.println(str1.capacity());

		str1.append(" Hi");			//increase capacity = capacity * 2 + 2
		System.out.println(str1);
		System.out.println(str1.capacity());

		//delete
		str2.delete(2,5);
		System.out.println(str2);
		



	}
}

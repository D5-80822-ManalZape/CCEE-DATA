class GetCharsDemo{
    public static void main(String[] args) {
        String str1 = new String("Hello James");
        char[] ch = new char[6];
        str1. getChars(6,11,ch,1);
        //System.out.print("GetChar : ");
        System.out.println(ch);
    }
}

class StringFormatDemo
{
	public static void main(String args[])
	{
		String str1 = "Hello"; 
		String str2 = "Friends";
		int num = 100;
		int num1 = 35;			//00035
		int num2 = 189;
		
		String str = String.format("%s %s %d", str1, str2, num);	//"Hello Friends 100"
		System.out.println(str);

		str = String.format("%1$s %2$s %1$s %3$d", str1, str2, num);	//"Hello Friends Hello 100"
		System.out.println(str);

		str = String.format("%05d", num1);
		System.out.println(str);		//00035

		str = String.format("%x",num2);
		System.out.println(str);

		str = String.format("%o",num2);
		System.out.println(str);


	}
}

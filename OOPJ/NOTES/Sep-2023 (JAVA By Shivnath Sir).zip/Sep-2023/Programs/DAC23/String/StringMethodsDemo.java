class StringMethodsDemo
{
	public static void main(String args[])
	{
		//charAt()
		String str;
		String str1 = "welcome";
		String str2 = new String("welcome");
		String str3 = "WeLcoMe";
		String str4 = "welfare";
		String str5 = "jiya joy";
		String str6 = "jiya";
		String str7 = "tiya toy";
		String str8 = "";		//empty string
		String str9 = "     ";

		char ch = str1.charAt(5);
		System.out.println(ch);

		System.out.println("str1.length(): " + str1.length());

		//getChars()
		char charr[] = new char[4];
		str1.getChars(2,6,charr,0);
		System.out.println(charr);

		//equals() and equalsIgnoreCase()

		System.out.println("str1.equals(str2) : "+str1.equals(str2));
		System.out.println("str1.equals(str3) : "+str1.equals(str3));
		System.out.println("str1.equalsIgnoreCase(str3) : "+str1.equalsIgnoreCase(str3));

		//compareTo()
		System.out.println("str1.compareTo(str2):"+str1.compareTo(str2));
		System.out.println("str1.compareTo(str4):"+str1.compareTo(str4));
		System.out.println("str6.compareTo(str5):"+str6.compareTo(str5));

		//replace()
		str =  str5.replace('j','t');
		System.out.println(str);


		System.out.println("str == str6 : " + str == str7);

		//indexOf()
		System.out.println("Welcome.indexOf(e): "+str1.indexOf('e'));
		System.out.println("Welcome.indexOf(p): "+str1.indexOf('p'));
		System.out.println("Welcome.indexOf(com): "+str1.indexOf("com"));

		//contains()
		System.out.println("Welcome.contains(com): " + str1.contains("com"));
		System.out.println("Welcome.contains(dom): " + str1.contains("dom"));
		System.out.println("Welcome.contains(c): " + str1.contains("c"));

		//isEmpty()
		System.out.println("str8.isEmpty(): " + str8.isEmpty());
		System.out.println("str9.isEmpty(): " + str9.isEmpty());
		
		//join()
		String day = "09";
		String month = "Oct";
		String year = "2023";

		String date = String.join("/",day,month,year);
		System.out.println(date);
		
	}
}

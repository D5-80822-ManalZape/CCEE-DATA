class SplitDemo
{
	public static void printArr(String []arr)
	{
		for(int i = 0; i < arr.length; i++)
                {
                        System.out.println(arr[i]);
                }
	}
		
	public static void main(String args[])
	{
		String str1 = "ab,ac,acd,bcd,bbc";
		String str2 = "ab-ac-acd-bcd-bbc";
		String str3 = "pq@rccc@xy@zccc";

		String [] strarr = str1.split(",");

		System.out.println("str1.split(@$) : ");
		printArr(strarr);

		String str = "Hi@KHow@KAre@KYou";
		strarr = str.split("@K");
		System.out.println("str.split(@K) : ");
		printArr(strarr);

		strarr = str2.split("-",3);
		System.out.println("str2.split(-,3) : ");
		printArr(strarr);

		strarr = str3.split("c",-1);
		System.out.println("str3.split(c,-1) : ");
		printArr(strarr);
	}
}

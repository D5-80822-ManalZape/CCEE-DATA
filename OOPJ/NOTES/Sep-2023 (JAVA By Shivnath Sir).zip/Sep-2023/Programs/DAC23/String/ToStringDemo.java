class Demo
{
	int a = 5;
}

class ToStringDemo
{
	public static void main(String args[])
	{
		Demo d = new Demo();

		System.out.println(d);		//System.out.println(d.toString());	

		String str = new String("welcome");
		System.out.println(str);	//System.out.println(str.toString());
	}
}

class MyGen <T>
{
	T ob;
	
	MyGen()
	{
		ob = null;
	}
	
	MyGen(T ob)		//Integer ob = 100;
	{
		this.ob = ob;
	}
	
	T getOb()
	{
		return ob;
	}
}

class First
{
	int val = 10;
	
	public String toString()
	{
		return "First[val = " + val + "]";
	}
}

class GenericDemo
{
	public static void main(String args[])
	{
		MyGen<Integer> mg1 = new MyGen<Integer>(100);
		int a = mg1.getOb();			// int = Integer OK, due to auto-unboxing
		System.out.println(a);	
		
		MyGen<Double> mg2 = new MyGen<Double>(23.5);
		double d = mg2.getOb();			
		System.out.println(d);
		
		MyGen<String> mg3 = new MyGen<String>("Welcome");
		String s = mg3.getOb();			
		System.out.println(s);
		
		First f1 = new First();
		MyGen<First> mg4 = new MyGen<First>(f1);
		First f = mg4.getOb();			
		System.out.println(f);
		
	}
}


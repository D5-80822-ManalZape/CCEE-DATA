class MyNonGen 
{
	Object ob;
	
	MyNonGen()
	{
	}
	
	MyNonGen(Object ob)		//Object ob = 100		
	{
		this.ob = ob;
	}
	
	Object getOb()
	{
		return ob;
	}
}

class NonGenDemo
{
	public static void main(String args[])
	{
		MyNonGen mg1 = new MyNonGen(100);
		int a = (Integer)mg1.getOb();			//int = (Integer)Object		
		System.out.println(a);
		
		MyNonGen mg2 = new MyNonGen("Welcome");
		String s = (String)mg2.getOb();				//String = (String)Object
		System.out.println(s);	

		mg1 = mg2;
		a = (Integer)mg1.getOb();			//int = (Integer)Object		
		System.out.println(a);
		
	}
}


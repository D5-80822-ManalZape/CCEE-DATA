class Adder<T extends Integer>
{
	T a;
	T b;

	Adder(T a, T b)
	{
		this.a = a;
		this.b = b;
	}

	T add()
	{
		return a + b;
	}
}

class GenericAddDemo
{
	public static void main(String args[])
	{
		Adder<Integer> twonums = new Adder<Integer>(5,10);
		System.out.println(twonums.add());
	}
}

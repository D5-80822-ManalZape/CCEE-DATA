class MyGen<T>
{
	T ob;

	MyGen()
	{
	}
	
	MyGen(T ob)
	{
		this.ob = ob;
	}
	
	void myFun(MyGen<? super Number> x)		//change ? to T, super to extends and observe the output
	{
		System.out.println(x);		//sop(mg2.toString());
	}
	
	public String toString()
	{
		if(ob == null) return null;
		return ob.toString();
	}
}

class GenericUseDemo
{
	public static void main(String args[])
	{
		MyGen<Integer> mg1 = new MyGen<Integer>(100);
		MyGen<Integer> mg2 = new MyGen<Integer>(50);

		MyGen<String> mg3 = new MyGen<String>("Welcome");
		MyGen<Double> mg4 = new MyGen<Double>(25.3);
		
		MyGen<Object> mg5 = new MyGen<Object>();

		//mg1.myFun(100);			//ERROR
		//mg1.myFun(mg2);			//OK
		//mg1.myFun(mg3);			//ERROR
		//mg1.myFun(mg4);
		mg1.myFun(mg5);
	}
}

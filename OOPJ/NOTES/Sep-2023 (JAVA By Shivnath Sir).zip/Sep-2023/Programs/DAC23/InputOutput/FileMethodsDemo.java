import java.io.*;
class FileMethodsDemo
{
	public static void main(String args[]) throws IOException
	{
		File f = new File("Serialization");
		File dir = new File("mydir1");
		File nf = new File("myfile1.csv");

		if(!f.exists())
		{
			return;
		}

		if(f.isDirectory())
		{
			System.out.println(f.getName() + " is a directory ");

			String filenames [] = f.list();		//It returns string array of filenames within the given folder

			for(String fname : filenames)
			{
				System.out.println(fname);
			}
		}

		//Create a directory
		if(!dir.exists())
		{
			dir.mkdir();
		}

		//create new file - we can use File, FileWriter, FileOutputStream
		if(!nf.exists())
		{
			nf.createNewFile();
		}

	}
}

import java.io.*;

class CharacterStreamIODemo
{
	public static void main(String args[]) throws IOException
	{
		File f1 = new File("myfile.txt");
		File f2 = new File("myoutfile.txt");

		if(!f1.exists())
		{
			System.out.println(f1.getName() + " does not exists !!");
			return;
		}

		//Reading from the file
		FileReader fr = new FileReader("myfile.txt");	//will read from myfile.txt
		//FileReader fr = new FileReader(f1);	//will read from myfile.txt
		FileWriter fw = new FileWriter(f2);	//will write to myoutfile.txt, does not append
		//FileWriter fw = new FileWriter(f2,true);	//will append to the file
									
		int ch;
		while((ch = fr.read()) != -1)
		{
			System.out.print((char)ch);	//console print
			fw.write(ch);
		}	

		fr.close();
		fw.close();
		System.out.println("I/O operation done sucessfully");
	}
}

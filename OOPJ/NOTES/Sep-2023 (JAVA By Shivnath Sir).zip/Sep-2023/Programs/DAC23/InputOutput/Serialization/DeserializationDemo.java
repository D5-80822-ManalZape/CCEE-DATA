import java.io.*;

class Demo implements Serializable
{
	int a;
	double d;
	String s;

	Demo()
	{
	}

	Demo(int a, double d, String s)
	{
		this.a = a;
		this.d = d;
		this.s = s;
	}

	public String toString()
	{
		return "Demo[a = " + a + ", d = " + d + ", s = " + s + "]";
	}
}

class DeserializationDemo
{
	public static void main(String args[]) throws IOException,ClassNotFoundException
	{
		FileInputStream fis = new FileInputStream("demoobj.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Demo dobj = (Demo)ois.readObject();		//return type of readObject is Object

		ois.close();
		
		System.out.println("Object of Demo deserialized successfully");
		System.out.println("Object state : " + dobj);
	}
}

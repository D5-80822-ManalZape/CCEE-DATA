import java.io.*;

class Demo implements Serializable
{
	int a;
	double d;
	String s;

	Demo()
	{
	}

	Demo(int a, double d, String s)
	{
		this.a = a;
		this.d = d;
		this.s = s;
	}

	public String toString()
	{
		return "Demo[a = " + a + ", d = " + d + ", s = " + s + "]";
	}
}

class SerializationDemo
{
	public static void main(String args[]) throws IOException
	{
		Demo demoObj = new Demo(15,123.5,"Welcome");

		FileOutputStream fos = new FileOutputStream("demoobj.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(demoObj);

		oos.flush();
		oos.close();
		
		System.out.println("Object state : " + demoObj);
		System.out.println("Object of Demo serialized successfully");
	}
}

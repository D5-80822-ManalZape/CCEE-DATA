import java.io.*;

class BufferedByteStreamIODemo
{
	public static void main(String args[]) throws IOException
	{
		File f1 = new File("myfile.txt");
		File f2 = new File("myoutfile.txt");

		if(f1.exists() == false)
		{
			System.out.println(f1.getName() + " does not exists !!");
			return;
		}

		FileInputStream fis = new FileInputStream("myfile.txt");//will read from myfile.txt
		System.out.println("To read from file : " + fis.available()); //Bytes available to read
		BufferedInputStream bis = new BufferedInputStream(fis);

		FileOutputStream fos = new FileOutputStream("myoutfile.txt");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		//BufferedOutputStream bos = new BufferedOutputStream(fos,true);	//will append
									
		int ch;
		while((ch = bis.read()) != -1)
		{
			System.out.print((char)ch);	//console print
			bos.write(ch);
		}	

		fis.close();
		bos.flush();
		fos.close();
		System.out.println("I/O operation done sucessfully");
	}
}

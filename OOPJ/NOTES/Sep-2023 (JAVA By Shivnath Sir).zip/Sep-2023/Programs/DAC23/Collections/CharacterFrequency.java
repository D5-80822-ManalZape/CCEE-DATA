import java.util.*;
class CharacterFrequency
{
	public static void main(String args[])
	{
		Map<Character,Integer> myCharMap = new TreeMap<Character,Integer>();
		String str = "aabaabaacaadddab";
		for(int i = 0; i < str.length(); i++)
		{
			char ch = str.charAt(i);
			if(myCharMap.get(ch) == null)
			{
				myCharMap.put(ch,1);
			} 
			else
			{
				int currVal = myCharMap.get(ch);
				myCharMap.put(ch,currVal+1);
			}
		}

		for(Map.Entry<Character,Integer> entry : myCharMap.entrySet())
		{
			System.out.println(entry.getKey() + " = " + entry.getValue());	
		}

	}
}

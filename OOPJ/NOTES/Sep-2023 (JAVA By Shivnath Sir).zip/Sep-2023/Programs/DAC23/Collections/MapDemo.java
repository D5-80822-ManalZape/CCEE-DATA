import java.util.*;

class MapDemo
{

	static void display(Collection <?> c)
	{
		if(c == null) return;

		for(Object ob : c)
		{
			System.out.println(ob);
		}
	}

	public static void main(String args[])
	{
		Map<Integer,String> myMap1 = new HashMap<Integer,String>();

		//put() - to add into the map.
		myMap1.put(1,"Shoaib");
		myMap1.put(2,"Rajan");
		myMap1.put(3,"Geeta");
		myMap1.put(4,"Nayara");
		myMap1.put(5,"Aman");

		//get() - to retrieve the value from the map associated with the key.
		String s = myMap1.get(4);
		System.out.println("Roll no. 4 is " + s);

		//size()
		System.out.println("Size of myMap1 : " + myMap1.size());
		
		//isEmpty()
		System.out.println("is myMap1 empty : " + myMap1.isEmpty());
		
		//Iterating using entrySet();
		//entrySet() - it gives the set of Map.Entry objects for the respective map.
		Set<Map.Entry<Integer,String>> mySet1 = myMap1.entrySet();
		System.out.println("Map elements are as below: ");
		//for(Map.Entry<Integer,String> entry : mySet1)

		for(Map.Entry<Integer,String> entry : myMap1.entrySet())
		{
			//System.out.println(entry);
			int key = entry.getKey();
			String value = entry.getValue();  //String value = myMap1.get(key);
			System.out.println("Roll = " + key + " Name = " + value);
			if(key == 3)
				entry.setValue("Rohit");
		}

		//remove()
		myMap1.remove(2);
		myMap1.put(6,"Rakesh");
		System.out.println("myMap1 after removing element with key 2 :");
		for(Map.Entry<Integer,String> entry: myMap1.entrySet())
		{
			System.out.println(entry);
		}
		
		//clear()
		//myMap1.clear();		//Removes all entries/elements from the Map
		
		//backed set 
		System.out.println("After clearing the map and then iterating the backed set : ");
		for(Map.Entry<Integer,String> entry : mySet1)
		{
			System.out.println(entry);
		}
		
		//containsKey()
		boolean boolRes = myMap1.containsKey(4);
		System.out.println("myMap1 contains the key 4 : " + boolRes);
		
		//keySet() : Returns set of keys
		Set<Integer> myKeySet = myMap1.keySet();
		System.out.println("All keys of the map received using keySet() method are: ");
		
		for(Integer key : myKeySet)
		{
			System.out.println(key);
			String s = myMap1.get(key);
			System.out.println(s);
		}
		
		//values() : Returns collection of values
		Collection<String> myValues = myMap1.values();
		System.out.println("All values of the map using values() method are: ");
		//for(String st : myValues)
		for(String st : myMap1.values())
		{
			System.out.println(st);
		}
		
	}
}

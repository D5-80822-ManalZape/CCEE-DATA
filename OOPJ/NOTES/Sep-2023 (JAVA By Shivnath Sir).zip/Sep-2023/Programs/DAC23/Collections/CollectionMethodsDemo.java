import java.util.*;

class CollectionMethodsDemo 
{
	static void display(List <String> myList)
	{
		for(String s : myList)
                {
                        System.out.println(s);
                }
	}

	public static void main(String args[])
	{
		List<String> myList1 = new ArrayList<String>();
	
		//add() method	
		myList1.add("Rohit");
		myList1.add("Aman");
		myList1.add("Sita");
		myList1.add("Geeta");
		myList1.add("Rohan");
		myList1.add("Geeta");
		myList1.add("Geeta");
		myList1.add("Geeta");

		display(myList1);

		//size()
		int s = myList1.size();
		System.out.println("\nsize of myList1 : " + s);

		//addAll()
		List<String> myList2 = new ArrayList<String>();
		myList2.add("Rajan");
		myList2.add("Meera");
		myList2.add("Aakash");

		myList1.addAll(myList2);
		System.out.println("\nmyList1 after addAll(myList2):");
		display(myList1);

		//clear()
		myList2.clear();
		System.out.println("\nmyList2 after clear():");
		display(myList2);

		System.out.println("\nmyList1 after myList2.clear():");
		display(myList1);

		//contains()
		boolean  boolRes = myList1.contains("Rohit");
		System.out.println("\nRohit exists in myList1: "+boolRes);

		//containsAll()
		myList2.add("Mohit");
		myList2.add("Geeta");

		boolRes = myList1.containsAll(myList2);
		System.out.println("\nmyList1.contatinsAll(myList2) : " + boolRes);

		//remove()
		myList1.remove("Geeta");
		System.out.println("\nmyList1.remove(Geeta):");
		display(myList1);

		//removeAll()
		myList2.add("Rohit");
		myList2.add("Rohan");
		myList1.removeAll(myList2);
		System.out.println("\nmyList1.removeAll(myList2):");
		display(myList1);

		//isEmpty()
		boolRes = myList1.isEmpty();
		System.out.println("\nmyList1.isEmpty(): " + boolRes);		

		//retainAll()
		List <String> myList3 = new ArrayList<String>();
		myList3.add("Sita");
		myList3.add("Rajan");
		myList3.add("Mukesh");
	
		myList1.retainAll(myList3);
		System.out.println("\nmyList1.retainAll(myList3): ");
		display(myList1);

		//toArray()
		System.out.println("\nmyList3.toArray(): ");
		Object[] arr = myList3.toArray();
		for(Object ob : arr)
		{
			System.out.println(ob);
		}

	}

}

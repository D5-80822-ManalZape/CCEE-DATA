import java.util.*;
class CollectionsClassMethodDemo
{
	static void display(Collection<?> c)
	{
		if(c == null) return;

		for(Object ob : c)
		{
			System.out.println(ob);
		}
	}

	public static void main(String args[])
	{
		List<Integer> myList1 = new LinkedList<Integer>();
		myList1.add(5);
		myList1.add(8);
		myList1.add(3);
		myList1.add(7);
		myList1.add(2);

		System.out.println("myList1 elements: ");
		display(myList1);

		//shuffle()
		Collections.shuffle(myList1);
		System.out.println("myList1 after shuffling: ");
		display(myList1);

		//sort()
		Collections.sort(myList1);
		System.out.println("myList1 elements after sorting: ");
		display(myList1);

		//max()
		Collections.max(myList1);
		System.out.println("max element in myList1: " + Collections.max(myList1));
		
		//min()
		Collections.min(myList1);
		System.out.println("min element in myList1: " + Collections.min(myList1));

	}
}

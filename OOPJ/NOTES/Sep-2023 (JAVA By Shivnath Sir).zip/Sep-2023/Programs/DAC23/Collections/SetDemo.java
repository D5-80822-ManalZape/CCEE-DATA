import java.util.*;

class SetDemo
{
	static void display(Collection <?> c)
	{
		if(c == null) return;

		for(Object ob : c)
		{
			System.out.println(ob);
		}
	}

	public static void main(String args[])
	{
		Set<String> mySet1 = new TreeSet<String>();	//Change it to HashSet,LinkedHashSet,TreeSet and observe the output
		mySet1.add("Mukesh");
		mySet1.add("Raman");
		mySet1.add("Aman");
		mySet1.add("Sridhar");
		mySet1.add("Kunal");

		display(mySet1);

		String str = "ababpcadxpzsbd";
		Set<Character> myCharSet = new TreeSet<Character>();
		for(int i = 0; i < str.length(); i++)
		{
			char ch = str.charAt(i);
			myCharSet.add(ch);
		}

		System.out.println("\nThe unique alphabets in the given string ababpcadxpzsbd are: ");
		display(myCharSet);
	}
}

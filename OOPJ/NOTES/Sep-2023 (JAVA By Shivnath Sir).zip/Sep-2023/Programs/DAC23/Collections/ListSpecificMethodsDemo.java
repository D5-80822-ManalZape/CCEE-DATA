import java.util.*;

class ListSpecificMethodsDemo 
{
	static void display(List <String> myList)
	{
		for(String s : myList)
                {
                        System.out.println(s);
                }
	}

	public static void main(String args[])
	{
		List<String> myList1 = new ArrayList<String>();
	
		//add() method	
		myList1.add("Rohit");
		myList1.add("Aman");
		myList1.add("Sita");
		myList1.add("Geeta");
		myList1.add("Aman");
		myList1.add("Rohan");

		display(myList1);

		//add(index,element)
		myList1.add(2,"Mohit");
		System.out.println("\nmyList1 after adding Mohit at index 2: ");
		display(myList1);

		//addAll()
		Set<String> myList2 = new HashSet<String>();
		myList2.add("Madan");
		myList2.add("Nayara");
		myList1.addAll(3,myList2);
		System.out.println("\nmyList1 after adding all elements from myList2 at index 3:");
		display(myList1);

		//get()
		String s = myList1.get(2);
		System.out.println("\nAt index 2 in myList1 : " + s);


		//indexOf()
		int idx = myList1.indexOf("Rohan");
		System.out.println("\nIndex of Rohan in myList1 : " + idx);

		//remove()
		myList1.remove(2);
		System.out.println("\nmyList1 after removing element at index 2:");
		display(myList1);

		//set()
		myList1.set(3,"Amaya");
		System.out.println("\nmyList1 after setting the value at index 3");
		display(myList1);

		//subList()
		List<String> myList3 = myList1.subList(3,6);
		System.out.println("myList3 - A sublist from myList1(3,6): ");
		display(myList3);

		//lastIndexOf()
		idx = myList1.lastIndexOf("Aman");
		System.out.println("\nmyList1.lastIndexOf(Aman): " + idx);


	}

}

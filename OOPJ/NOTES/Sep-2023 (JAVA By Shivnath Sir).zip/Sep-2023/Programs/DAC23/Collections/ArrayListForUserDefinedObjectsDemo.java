import java.util.*;

class Student implements Comparable<Student>
{
	int rollNo;
	String name;
	int age;

	Student()
	{
	}

	Student(int rollNo, String name, int age)
	{
		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
	}

	public int hashCode()
	{
		return (rollNo + age);
	}

	public boolean equals(Object obj)
	{
		if(obj == null) return false;

		Student s = (Student) obj;
		if(this.rollNo == s.rollNo && this.name.equals(s.name) && this.age == s.age)
		{
			return true;
		}
		return false;
	}

	public int compareTo(Student s)
	{
		/*if(this.rollNo == s.rollNo) return 0;
		if(this.rollNo < s.rollNo) return -1;
		if(this.rollNo > s.rollNo) return 1;

		return 0;*/

		return this.rollNo - s.rollNo;
	}

	public String toString()
	{
		return "Student[roll = " + rollNo + ", name = " + name + ", age = " + age + "]";
	}
}

//Comparator class
class StudentAgeComparator implements Comparator<Student>
{
	public int compare(Student s1, Student s2)
	{
		/*if(s1.age == s2.age) return 0;
		if(s1.age < s2.age) return -1;
		if(s1.age > s2.age) return 1;

		return 0;*/

		return s1.age - s2.age;
	}
}

//comparator class
class StudentNameComparator implements Comparator<Student>
{
	public int compare(Student s1, Student s2)
	{
		return s1.name.compareTo(s2.name);		//here we are using compareTo() of String class to compare two Strings i.e. names.
	}
}


class ArrayListForUserDefinedObjectsDemo
{
	static void display(Collection<?> c)
	{
		if(c == null) return;

		for(Object ob : c)
		{
			System.out.println(ob);		//System.out.println(ob.toString());
		}
	}

	public static void main(String args[])
	{

		List<Student> studList = new ArrayList<Student>();

		Student s1 = new Student(4,"Mohid",23);
		Student s2 = new Student(6,"Aakash",21);

		studList.add(s1);
		studList.add(s2);
		studList.add(new Student(3,"Mohan",22));
		studList.add(new Student(1,"Geeta",20));
		studList.add(new Student(5,"Joseph",24));
		studList.add(new Student(2,"Rajesh",25));

		//displaying studList
		display(studList);

		//contains()
		boolean boolRes = studList.contains(s1);
		System.out.println("s1 exists in studList : " + boolRes);

		Student s = new Student(3,"Mohan",22);
		boolRes = studList.contains(s);
                System.out.println("s exists in studList : " + boolRes);

		//containsAll(), remove(), removeAll(), retainAll() internally uses equals() method.
		studList.remove(s);
		System.out.println("studList after removing s:");
		display(studList);

		//sorting
		Collections.sort(studList);	//Here sort() will use compareTo() of class Student

		System.out.println("studList after sorting: ");
		display(studList);

		//sorting in reverse order
		Collections.sort(studList,Collections.reverseOrder());
		System.out.println("studList after sorting in reverse order: ");
		display(studList);

		//sorting using AgeComparator
		StudentAgeComparator ageComp = new StudentAgeComparator();
		Collections.sort(studList,ageComp);	//here sort() method will use compare() of StudentAgeComparator.
		System.out.println("studList after sorting based on age : ");
		display(studList);

		//sorting in reverse order based on age
		Collections.sort(studList,Collections.reverseOrder(ageComp));
		System.out.println("studList after sorting in reverse order of age : ");
		display(studList);

		//Sorting based on names
		StudentNameComparator nameComp = new StudentNameComparator();
		Collections.sort(studList,nameComp);

		//Collections.sort(studList,new StudentNameComparator());
		System.out.println("studList after sorting based on name: ");
		display(studList);

	}
}

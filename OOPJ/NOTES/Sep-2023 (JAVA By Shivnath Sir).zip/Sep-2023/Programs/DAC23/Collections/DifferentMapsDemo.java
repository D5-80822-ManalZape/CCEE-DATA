import java.util.*;

class DifferentMapsDemo
{
	public static void main(String args[])
	{
		Map<String,String> myMap1 = new TreeMap<String,String>(); //change to HashMap,LinkedHashMap and TreeMap and then observe the output.
		myMap1.put("3.three","Javed");
		myMap1.put("2.two","Rakesh");
		myMap1.put("5.five","Aman");
		myMap1.put("4.four","Geeta");
		myMap1.put("1.one","Sohan");

		//Iterating the map elements

		for(Map.Entry<String,String> entry : myMap1.entrySet())
		{
			System.out.println(entry.getKey() + "," + entry.getValue());
		}
	}
}

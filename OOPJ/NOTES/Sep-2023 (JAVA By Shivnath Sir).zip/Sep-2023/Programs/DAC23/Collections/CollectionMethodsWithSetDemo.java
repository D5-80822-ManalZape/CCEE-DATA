import java.util.*;

class CollectionMethodsWithSetDemo 
{
	static void display(Set <String> mySet)
	{
		for(String s : mySet)
                {
                        System.out.println(s);
                }
	}

	public static void main(String args[])
	{
		Set<String> mySet1 = new HashSet<String>();
	
		//add() method	
		mySet1.add("Rohit");
		mySet1.add("Aman");
		mySet1.add("Sita");
		mySet1.add("Geeta");
		mySet1.add("Rohan");
		mySet1.add("Geeta");
		mySet1.add("Geeta");
		mySet1.add("Geeta");

		display(mySet1);

		//size()
		int s = mySet1.size();
		System.out.println("\nsize of mySet1 : " + s);

		//addAll()
		Set<String> mySet2 = new HashSet<String>();
		mySet2.add("Rajan");
		mySet2.add("Meera");
		mySet2.add("Aakash");

		mySet1.addAll(mySet2);
		System.out.println("\nmySet1 after addAll(mySet2):");
		display(mySet1);

		//clear()
		mySet2.clear();
		System.out.println("\nmySet2 after clear():");
		display(mySet2);

		System.out.println("\nmySet1 after mySet2.clear():");
		display(mySet1);

		//contains()
		boolean  boolRes = mySet1.contains("Rohit");
		System.out.println("\nRohit exists in mySet1: "+boolRes);

		//containsAll()
		mySet2.add("Mohit");
		mySet2.add("Geeta");

		boolRes = mySet1.containsAll(mySet2);
		System.out.println("\nmySet1.contatinsAll(mySet2) : " + boolRes);

		//remove()
		mySet1.remove("Geeta");
		System.out.println("\nmySet1.remove(Geeta):");
		display(mySet1);

		//removeAll()
		mySet2.add("Rohit");
		mySet2.add("Rohan");
		mySet1.removeAll(mySet2);
		System.out.println("\nmySet1.removeAll(mySet2):");
		display(mySet1);

		//isEmpty()
		boolRes = mySet1.isEmpty();
		System.out.println("\nmySet1.isEmpty(): " + boolRes);		

		//retainAll()
		Set <String> mySet3 = new HashSet<String>();
		mySet3.add("Sita");
		mySet3.add("Rajan");
		mySet3.add("Mukesh");
	
		mySet1.retainAll(mySet3);
		System.out.println("\nmySet1.retainAll(mySet3): ");
		display(mySet1);

		//toArray()
		System.out.println("\nmySet3.toArray(): ");
		Object[] arr = mySet3.toArray();
		for(Object ob : arr)
		{
			System.out.println(ob);
		}

	}

}

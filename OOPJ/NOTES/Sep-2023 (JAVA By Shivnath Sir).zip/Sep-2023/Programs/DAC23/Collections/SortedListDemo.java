import java.util.*;
class SortedListDemo
{
	static void display(Collection<?> c)
	{
		if(c == null) return;

		for(Object ob : c)
		{
			System.out.println(ob);
		}
	}

	public static void main(String args[])
	{
		List<Integer> myList1 = new LinkedList<Integer>();
		myList1.add(5);
		myList1.add(8);
		myList1.add(3);
		myList1.add(7);
		myList1.add(2);

		System.out.println("myList1 elements: ");
		display(myList1);

		Collections.sort(myList1);
		System.out.println("myList1 elements after sorting: ");
		display(myList1);
	}
}

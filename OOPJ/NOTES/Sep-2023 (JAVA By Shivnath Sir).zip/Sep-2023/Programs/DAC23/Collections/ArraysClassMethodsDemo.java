import java.util.*;

class ArraysClassMethodsDemo
{
	static void display(int []arr)
	{
		for(int v : arr)
		{
			System.out.println(v);
		}
	}

	public static void main(String args[])
	{
		int arr[] = {2,8,5,1,7};
		int arr1[] = {2,8,5,1,7};

		System.out.println("Array elements : ");
		display(arr);

		//toString()
		System.out.println("String representation of arr : ");
		//String str = Arrays.toString(arr);
		//System.out.println(str);
		System.out.println(Arrays.toString(arr));

		//sort()
		Arrays.sort(arr);
		System.out.println("Array after sorting: ");
		display(arr);

		//binarySearch() : It is important that array must be sorted first.
		int idx = Arrays.binarySearch(arr,3);
		System.out.println("index of 5 in arr: " + idx);

		//equals() : checks if two arrays contains same elements with same order
		boolean boolRes = Arrays.equals(arr,arr1);
		System.out.println("arr equals arr1 is " + boolRes);

		int []arr2 = new int[5];
		Arrays.fill(arr2,1);
		//Arrays.fill(arr2,2,4,1);	//from index : 2, to index : 4 exclusive, fill with 1
		System.out.println("arr2 after filling all elements with 1 : ");
		display(arr2);

		int []arr3 = Arrays.copyOf(arr1,8);
		System.out.println("arr3 elements which is copyOf arr1:");
		display(arr3);

		
	}
}

import java.util.*;

class ArrayListDemo
{
	public static void main(String args[])
	{
		List<String> myList1 = new ArrayList<String>();
		
		myList1.add("Rohit");
		myList1.add("Aman");
		myList1.add("Sita");
		myList1.add("Geeta");
		myList1.add("Rohan");

		//Iterating array list using for-each loop
		System.out.println("Iteration using for-each");	
		for(String s : myList1)
		{
			System.out.println(s);
		}

		//Iterating arraylist using Iterator
		System.out.println("Iteration using Iterator:");
		Iterator <String> it = myList1.iterator();	//Returns an Iterator objects
		while(it.hasNext())
		{
			String s = it.next();
			System.out.println(s);
		}

		
		//Iterating arraylist using ListIterator
		System.out.println("Iteration using ListIterator:");
		ListIterator <String> lit = myList1.listIterator();	//Returns an ListIterator object
		while(lit.hasNext())
		{
			String s = lit.next();
			System.out.println(s);
		}

		System.out.println("Iterating using ListIterator in reverse direction:");
		while(lit.hasPrevious())
		{
			String s = lit.previous();
			System.out.println(s);
		}

		//Iterating using Enumeration
		System.out.println("Iteration using Enumeration");
		Enumeration <String> em = Collections.enumeration(myList1);
		while(em.hasMoreElements())
		{
			String s = em.nextElement();
			System.out.println(s);
		}







	}

}

class First
{
	void myFun()
	{
	}
}

class Second extends First
{
	static void myFun()
	{
	}
}

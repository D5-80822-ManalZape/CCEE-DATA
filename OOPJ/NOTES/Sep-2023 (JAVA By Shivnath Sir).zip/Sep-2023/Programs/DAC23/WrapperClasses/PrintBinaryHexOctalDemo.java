class PrintBinaryHexOctal
{
	public static void main(String args[])
	{
		int num = 108;
		Integer numObj = new Integer(108);

		String res = Integer.toBinaryString(num);
		System.out.println(res);

		res = Integer.toHexString(numObj);
		System.out.println(res);

		res = Integer.toOctalString(num);
		System.out.println(res);

	}
}

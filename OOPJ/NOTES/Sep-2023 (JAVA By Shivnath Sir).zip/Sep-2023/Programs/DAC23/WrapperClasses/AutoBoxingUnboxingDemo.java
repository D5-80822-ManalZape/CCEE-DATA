class Demo
{
	public static Integer myFun(Integer iobj)		//Integer iobj = 25;
	{
		System.out.println(iobj);
		Integer res = iobj * 2;
		return res;
	}
}

class AutoBoxingUnboxingDemo
{
	public static void main(String args[])
	{
		int rs = Demo.myFun(25);
		System.out.println(rs);
	}
}


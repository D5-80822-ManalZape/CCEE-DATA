class Add
{
	public static void main(String args[])
	{
		//Iterating args[] array
		double sum = 0;

		for (int i = 0; i < args.length; i++)
		{
			Double dobj = new Double(args[i]);
			sum = sum + dobj;
			//sum = sum + Double.parseDouble(args[i]);
		}

		System.out.println(sum);
	}
}

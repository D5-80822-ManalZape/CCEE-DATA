class Demo
{
	public static Integer myFun(Integer iobj)		//Integer iobj = 25;
	{
		System.out.println(iobj);
		Integer res = new Integer(iobj.intValue() * 2);
		return res;
	}
}

class BoxingUnboxingDemo
{
	public static void main(String args[])
	{
		int rs = Demo.myFun(new Integer(25)).intValue();
		System.out.println(rs);
	}
}


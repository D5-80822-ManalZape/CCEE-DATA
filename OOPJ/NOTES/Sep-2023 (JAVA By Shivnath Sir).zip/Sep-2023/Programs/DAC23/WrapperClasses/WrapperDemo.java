class WrapperDemo
{
	public static void main(String args[])
	{
		//Integer iobj1 = new Integer("253");
		Integer iobj1 = new Integer(25);
		Integer iobj2 = new Integer("53");
		
		System.out.println(iobj1);

		//compareTo()
		int res = iobj1.compareTo(iobj2);
		System.out.println(res);

		//parseInt()

		String str = "275";
		int a = Integer.parseInt(str);
		System.out.println(a);

		//Character Object
		Character chobj = new Character('A');
		System.out.println(chobj);

		char ch = Character.toLowerCase('B');
		System.out.println(ch);
	

	}
}

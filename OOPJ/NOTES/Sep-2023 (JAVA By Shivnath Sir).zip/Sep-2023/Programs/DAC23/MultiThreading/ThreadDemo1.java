class MyThread extends Thread
{
	MyThread()
	{
	}

	MyThread(String tname)
	{
		super(tname);
	}

	public void run()
	{
		System.out.println(this.getName() + ": started its execution");
		System.out.println(this.getName() + ": completed its execution");
	}
}

class ThreadDemo1 
{
	public static void main(String args[])
	{
		//Creating the thread objects
		MyThread mth1 = new MyThread("mythread1");
		MyThread mth2 = new MyThread("mythread2");
		MyThread mth3 = new MyThread("mythread3");

		mth1.start();
		mth2.start();
		mth3.start();

		String currThreadName = Thread.currentThread().getName();
		System.out.println(currThreadName + " is the current thread here");

		System.out.println("program completed");
	}
}

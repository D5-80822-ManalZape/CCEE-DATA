class MyThread implements Runnable 
{
	Thread t;

	MyThread()
	{
		t = new Thread(this);
		t.start();
	}

	MyThread(String tname)
	{
		//t = new Thread(this,tname);
		t = new Thread(this);
		t.setName(tname);
		t.start();
	}

	public void run()
	{
		System.out.println(t.getName() + ": completed its execution");
	}
}

class ThreadUsingRunnableDemo2
{
	public static void main(String args[]) throws InterruptedException
	{
		MyThread mth1 = new MyThread("thread1");		//Runnable object
		MyThread mth2 = new MyThread("thread2");		//Runnable object
		MyThread mth3 = new MyThread("thread3");		//Runnable object
							
		mth1.t.join();
		System.out.println("main thread completed");	
	}
}

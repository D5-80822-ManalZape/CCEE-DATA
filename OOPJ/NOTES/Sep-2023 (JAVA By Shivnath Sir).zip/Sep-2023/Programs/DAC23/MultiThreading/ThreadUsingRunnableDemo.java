class MyThread implements Runnable
{
	public void run()
	{
		System.out.println("MyThread completed its execution");
	}
}

class ThreadUsingRunnableDemo
{
	public static void main(String args[]) throws InterruptedException
	{
		MyThread mth1 = new MyThread();		//Runnable object
		Thread t1 = new Thread(mth1);		//Thread object
	       	t1.start();
		t1.join();
		System.out.println("main thread completed");	
	}
}

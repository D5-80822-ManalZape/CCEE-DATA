//Expected Output : [Hello] [Friends] [Welcome]
class StringPrinter
{
	void print(String str)		//remove synchronized and observe the output.
	{
		try
		{
			Thread.sleep(2000);
			System.out.print("[");			//[Hello]
			Thread.sleep(2000);
			System.out.print(str);
			System.out.print("]");
			//wait();			//wait(),notify(),notifyall() must be within 
							//synchronized block or stament.
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
}

class MyThread implements Runnable
{
	Thread t;
	StringPrinter sp;
	String strToPrint;
	
	MyThread(StringPrinter sp, String strToPrint)
	{
		t = new Thread(this);
		this.sp = sp;
		this.strToPrint = strToPrint;
		
		t.start();
	}
	
	public void run()
	{
		synchronized(sp)		//synchronized block for shared resource/object
		{
			sp.print(strToPrint);
		}
	}
}


class SynchronizedBlockDemo
{
	public static void main(String args[])
	{
		StringPrinter sp = new StringPrinter();
		MyThread mth1 = new MyThread(sp,"Hello");
		MyThread mth2 = new MyThread(sp,"Friends");
		MyThread mth3 = new MyThread(sp,"Welcome");		
	}
}


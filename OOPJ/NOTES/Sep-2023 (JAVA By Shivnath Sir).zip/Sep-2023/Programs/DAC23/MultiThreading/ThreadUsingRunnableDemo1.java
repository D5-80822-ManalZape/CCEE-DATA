class MyThread implements Runnable 
{
	Thread t;

	MyThread()
	{
		t = new Thread(this);
		t.start();
	}

	public void run()
	{
		System.out.println("MyThread completed its execution");
	}
}

class ThreadUsingRunnableDemo
{
	public static void main(String args[]) throws InterruptedException
	{
		MyThread mth1 = new MyThread();		//Runnable object
		//Thread t1 = new Thread(mth1);		//Thread object
		mth1.t.join();
		System.out.println("main thread completed");	
	}
}

class MyThread extends Thread
{
	public void run()
	{
		System.out.println("MyThread run method executed");
	}
}

class ThreadDemo 
{
	public static void main(String args[])
	{
		//Creating the thread objects
		MyThread mth1 = new MyThread();
		mth1.start();
		System.out.println(mth1.getPriority());
		System.out.println("Main method completed");
	}
}

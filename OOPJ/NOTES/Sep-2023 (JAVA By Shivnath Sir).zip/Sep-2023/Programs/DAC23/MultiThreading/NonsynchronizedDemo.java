class StringPrinter
{
	void print(String str)
	{
		System.out.print("[");			//[Hello]
		Thread.sleep(500);
		System.out.print(str);
		System.out.print("]");
	}
}

class MyThread implements Runnable
{
	Thread t;
	StringPrinter sp;
	String strToPrint;
	
	MyThread(StringPrinter sp, String strToPrint)
	{
		t = new Thread(this);
		this.sp = sp;
		this.strToPrint = strToPrint;
		
		t.start();
	}
	
	public void run()
	{
		sp.print(strToPrint);
	}
}


class NonSynchronizedDemo
{
	public static void main(String args[])
	{
		StringPrinter sp = new StringPrinter();
		MyThread mth1 = new MyThread(sp,"Hello");
		MyThread mth2 = new MyThread(sp,"Friends");
		MyThread mth3 = new MyThread(sp,"Welcome");		
	}
}


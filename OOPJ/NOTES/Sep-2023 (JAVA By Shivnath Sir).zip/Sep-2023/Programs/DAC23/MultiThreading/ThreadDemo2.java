class MyThread extends Thread
{
	MyThread()
	{
	}

	MyThread(String tname)
	{
		super(tname);
	}

	public void run() 
	{
		try
		{
			System.out.println(Thread.currentThread().getName() + ": started");
			Thread.sleep(2000);
			System.out.println(Thread.currentThread().getName() + ": completed");
		}
		catch(InterruptedException e)
		{
		}
	}
}

class ThreadDemo2 
{
	public static void main(String args[]) throws InterruptedException
	{
		//Creating the thread objects
		MyThread mth1 = new MyThread("mythread1");
		MyThread mth2 = new MyThread("mythread2");
		MyThread mth3 = new MyThread("mythread3");

		mth1.start();
		mth2.start();
		mth3.start();

		mth1.join();	//main thread will wait until mth1 completes its work and join here
		mth2.join();	
		mth3.join();

		//Thread.sleep(5000);		//1000 milliseconds = 1 second 
						


		System.out.println(Thread.currentThread().getName()+ " thread completed");
	}
}

class MyThread implements Runnable 
{

	public void run()
	{
		System.out.println(Thread.currentThread().getName() + ": completed its execution");
	}
}

class ThreadUsingRunnableDemo3
{
	public static void main(String args[]) throws InterruptedException
	{
		MyThread mth1 = new MyThread();		//Runnable object
		MyThread mth2 = new MyThread();		//Runnable object
		MyThread mth3 = new MyThread();		//Runnable object
		
		Thread t1 = new Thread(mth1);
		Thread t2 = new Thread(mth2);
		Thread t3 = new Thread(mth3,"thread3");

		t1.setName("thread1");
		t2.setName("thread2");
		//t3.setName("thread3);

		t1.start();
		t2.start();
		t3.start();
							
		t1.join();
		t2.join();
		t3.join();

		System.out.println("main thread completed");	
	}
}

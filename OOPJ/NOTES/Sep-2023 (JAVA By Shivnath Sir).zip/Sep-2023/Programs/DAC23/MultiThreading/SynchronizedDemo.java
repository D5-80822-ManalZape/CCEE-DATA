//Expected Output : [Hello] [Friends] [Welcome]
class StringPrinter
{
	synchronized void print(String str)		//remove synchronized and observe the output.
	{
		try
		{
			Thread.sleep(2000);
			System.out.print("[");			//[Hello]
			Thread.sleep(2000);
			System.out.print(str);
			System.out.print("]");
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
}

class MyThread implements Runnable
{
	Thread t;
	StringPrinter sp;
	String strToPrint;
	
	MyThread(StringPrinter sp, String strToPrint)
	{
		t = new Thread(this);
		this.sp = sp;
		this.strToPrint = strToPrint;
		
		t.start();
	}
	
	public void run()
	{
		sp.print(strToPrint);
	}
}


class SynchronizedDemo
{
	public static void main(String args[])
	{
		StringPrinter sp = new StringPrinter();
		MyThread mth1 = new MyThread(sp,"Hello");
		MyThread mth2 = new MyThread(sp,"Friends");
		MyThread mth3 = new MyThread(sp,"Welcome");		
	}
}


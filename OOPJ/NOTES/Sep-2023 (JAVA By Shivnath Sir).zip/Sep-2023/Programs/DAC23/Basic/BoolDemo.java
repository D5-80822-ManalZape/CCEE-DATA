class BoolDemo
{
	public static void main(String args[])
	{
		int a = 5;
		int b = 10;
		
		/*if(a > b)
		{
			System.out.println("true");
		}	
		else
		{
			System.out.println("false");
		}*/

		boolean res = a > b;

		System.out.println(res);

		//byte c = 128;		//Possible lossy conversion from int to byte.
		byte c = 127;		//OK as 127 is in the range of byte.
		System.out.println(c);

		float f = 23.56f;
		System.out.println(f);
	}
}

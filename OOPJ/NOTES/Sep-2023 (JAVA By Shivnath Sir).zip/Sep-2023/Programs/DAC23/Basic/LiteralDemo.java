class LiteralDemo
{
	public static void main(String args[])
	{
		//int num = 93;
		int num = 0X5D;
		System.out.println(num);

		long val = 2361111111L;
		System.out.println(val);

		float f = 43.7f;
		System.out.println(f);

		//char ch = 'a';
		char ch = '\141';
		//char ch = '\u0061';

		System.out.println(ch);

		//String str = "Hello Friends";
		//System.out.println(""Hello Friends"");		//Hello Friends, "Hello Friends"
		System.out.println("\"Hello Friends\"");
	}
}

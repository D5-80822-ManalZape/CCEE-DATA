class BreakLoopDemo {
        public static void main(String args[]) {
                
		outer: for (int i = 1; i <= 5; i++)
                {
                        inner: for (int j = 1; j <= 5; j++)
                        {
                                System.out.print(j+"\t");

				if(j == i) 
				{
					break ;	//equivalent to 'break inner'
				}

                        }
			System.out.println();
                }
        }
}


class ScopeDemo
{
	static int p ;

	public static void myFun()
	{
		int a = 10;
		System.out.println(a);	//OK

		{
			//int a = 15;	//ERROR; variable a is already declared in this scope.
			int b = 5;
			System.out.println(b);
		}

	}

	static int q;

	
	public static void main()
	{
		myFun();
		//System.out.println(a);	//ERROR
	}
}

class TypePromotionDemo
{
	public static void main(String args[])
	{
		int a = 5;
		short b = 10;
		long c = 15;

		int res = (int)(a + b + c) ;
		System.out.println(res);

		byte p = 25;
		byte q = 30;

		byte r = (byte)(p + q);		
		System.out.println(r);
	}
}

//This is a program for demonstration only.

/**
This is a demo program.
This is to learn how to run a java program.
**/

public class MyFirstProgram
{
	/**
	This is the main method from where execution will start.
	**/
	public static void main(String args[])
	{
		System.out.println("This is my first program");
	}
}



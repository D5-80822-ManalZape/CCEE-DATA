class CharDemo
{
	public static void main(String args[])
	{
		char ch; 

		ch = 'y';
		System.out.println(ch);
	}
}

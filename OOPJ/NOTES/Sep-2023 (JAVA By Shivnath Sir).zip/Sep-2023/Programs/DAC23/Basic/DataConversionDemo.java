class DataConversionDemo
{
	public static void main(String args[])
	{
		int a;
		long b = 25;
		a = (int)b;
		System.out.println(a);

		float c  = (float)23.5;
		double d = 25.4;
		c = (float)d;
		System.out.println(c);

		d = (double)c;
		System.out.println(d);

		a = (int)c;
		System.out.println(a);

		a = 258;
		byte p = (byte)a;
		System.out.println(p);

		a = 130;
		p = (byte)a;
		System.out.println(p);

		c = 130.56f;
		p = (byte)c;
		System.out.println(p);


		char ch = 'x';
		a = ch;
		System.out.println(a);		

		a = 65;
		ch = (char)a;
		System.out.println(ch);

		ch = (char)97.5;
		System.out.println(ch);

	}
}

class SwitchCaseStringDemo
{
	public static void main(String args[])
	{

		String choice = "three";

		switch(choice)
		{
				
			case "one":
				System.out.println("case one");
				break;

			default:
				System.out.println("default case");
			
			case "two":
				System.out.println("case two");
				break;

		}

		System.out.println("Out of switch case");
	}
}

class LabeledBlockDemo
{
	

	public static void myFun()
	{
		boolean b = true;

		block1:
		{
			System.out.println("block1 code");
		}

		block2: 
		{
			System.out.println("Inside block2");

			block3:
			{
				System.out.println("Inside block3");
				if(b)		//if(true)
				{
					break block2;
				}
				System.out.println("block3 code");
			}

			System.out.println("Out of block3");
		}

		System.out.println("Out of block2");
	}



	public static void main(String args[])
	{
		myFun();
	}
}

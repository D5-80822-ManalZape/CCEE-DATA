class ShiftOpDemo
{
	public static void main(String args[])
	{
		byte b = 2;
		byte res = (byte)(b << 5);
		System.out.println(res);

		b = -6;
		res = (byte)(b >> 1);
		System.out.println(res);

		int c = -6;
		int r = b >>> 1;
		System.out.println(r);
	}
}
